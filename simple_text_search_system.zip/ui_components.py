import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import threading
import re

class PDFSearchUI:
    def __init__(self, root, app):
        self.root = root
        self.app = app
        self.processing_window = None
        self.page_window = None
        self.extracted_text_window = None
        self.last_search_text = ""  # Track last search for highlighting
        self.create_main_ui()
    
    def create_main_ui(self):
        """Create the main user interface"""
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        
        # Configure grid weights
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(3, weight=1)
        
        # Header section
        header_frame = ttk.LabelFrame(main_frame, text="📄 Document", padding="10")
        header_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        header_frame.columnconfigure(1, weight=1)
        
        # File selection
        ttk.Button(header_frame, text="📂 Select PDF File", command=self.app.select_pdf).grid(row=0, column=0, padx=(0, 10))
        self.file_label = ttk.Label(header_frame, text="No file selected")
        self.file_label.grid(row=0, column=1, sticky=(tk.W, tk.E))
        
        # File info and extracted text button
        info_frame = ttk.Frame(header_frame)
        info_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(5, 0))
        info_frame.columnconfigure(1, weight=1)
        
        self.info_label = ttk.Label(info_frame, text="")
        self.info_label.grid(row=0, column=0, sticky=tk.W)
        
        self.view_extracted_btn = ttk.Button(
            info_frame, 
            text="👁️ View Extracted Text", 
            command=self.show_extracted_text,
            state="disabled"
        )
        self.view_extracted_btn.grid(row=0, column=1, sticky=tk.E)
        
        # Search section
        search_frame = ttk.LabelFrame(main_frame, text="🔍 Search for Text", padding="10")
        search_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        search_frame.columnconfigure(0, weight=1)
        
        # Search text area
        self.search_text = scrolledtext.ScrolledText(search_frame, height=4, width=70)
        self.search_text.grid(row=0, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Search buttons
        button_frame = ttk.Frame(search_frame)
        button_frame.grid(row=1, column=0, columnspan=3, sticky=tk.W)
        
        ttk.Button(button_frame, text="🔍 Find Page", command=self.perform_search).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="🧹 Clear", command=self.clear_search).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="⚙️ Options", state="disabled").pack(side=tk.LEFT)
        
        # Results section
        results_frame = ttk.LabelFrame(main_frame, text="📋 Search Results", padding="10")
        results_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        results_frame.columnconfigure(0, weight=1)
        results_frame.rowconfigure(0, weight=1)
        
        # Results canvas with scrollbar
        results_canvas = tk.Canvas(results_frame)
        scrollbar = ttk.Scrollbar(results_frame, orient="vertical", command=results_canvas.yview)
        self.results_scrollable_frame = ttk.Frame(results_canvas)
        
        self.results_scrollable_frame.bind(
            "<Configure>",
            lambda e: results_canvas.configure(scrollregion=results_canvas.bbox("all"))
        )
        
        results_canvas.create_window((0, 0), window=self.results_scrollable_frame, anchor="nw")
        results_canvas.configure(yscrollcommand=scrollbar.set)
        
        results_canvas.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # Status bar
        self.status_bar = ttk.Label(main_frame, text="Ready", relief=tk.SUNKEN)
        self.status_bar.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E))
    
    def perform_search(self):
        """Perform search when button is clicked"""
        search_text = self.search_text.get("1.0", tk.END)
        self.last_search_text = search_text.strip()  # Save for highlighting
        self.app.search_text(search_text)
    
    def clear_search(self):
        """Clear search text and results"""
        self.search_text.delete("1.0", tk.END)
        self.last_search_text = ""
        self.clear_results()
    
    def clear_results(self):
        """Clear all results from display"""
        for widget in self.results_scrollable_frame.winfo_children():
            widget.destroy()
    
    def display_search_results(self, results):
        """Display search results in UI"""
        self.clear_results()
        
        if not results:
            no_results_label = ttk.Label(
                self.results_scrollable_frame, 
                text="No matches found for your search.",
                foreground="gray"
            )
            no_results_label.pack(pady=20)
            return
        
        # Add debug info
        debug_label = ttk.Label(
            self.results_scrollable_frame,
            text=f"Found {len(results)} match(es)",
            font=("Arial", 10, "italic"),
            foreground="blue"
        )
        debug_label.pack(pady=(0, 10))
        
        for result in results:
            self.create_result_card(result)
    
    def create_result_card(self, result):
        """Create a result card for display"""
        card_frame = ttk.Frame(self.results_scrollable_frame, relief="raised", borderwidth=1)
        card_frame.pack(fill=tk.X, pady=5, padx=5)
        card_frame.columnconfigure(1, weight=1)
        
        # Page info
        page_label = ttk.Label(
            card_frame, 
            text=f"📄 Page {result['page_num']}",
            font=("Arial", 10, "bold")
        )
        page_label.grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        
        # Confidence and match type
        confidence_text = f"Match: {result['confidence']*100:.0f}% ({result['match_type']})"
        confidence_color = "green" if result['confidence'] > 0.9 else "orange" if result['confidence'] > 0.7 else "red"
        
        confidence_label = ttk.Label(
            card_frame, 
            text=confidence_text,
            foreground=confidence_color
        )
        confidence_label.grid(row=0, column=1, sticky=tk.W)
        
        # Preview
        preview_text = result['preview'] if len(result['preview']) < 300 else result['preview'][:300] + "..."
        preview_label = ttk.Label(
            card_frame, 
            text=f"\"{preview_text}\"",
            font=("Arial", 9),
            foreground="gray"
        )
        preview_label.grid(row=1, column=0, columnspan=2, sticky=tk.W, pady=(5, 10))
        
        # Action buttons
        button_frame = ttk.Frame(card_frame)
        button_frame.grid(row=2, column=0, columnspan=2, sticky=tk.W)
        
        ttk.Button(
            button_frame, 
            text="👁️ View Page", 
            command=lambda p=result['page_num'], m=result.get('matched_text', ''): self.app.view_page(p, m)
        ).pack(side=tk.LEFT, padx=(0, 5))
        
        ttk.Button(
            button_frame, 
            text="📎 Copy Text", 
            command=lambda t=result['matched_text']: self.copy_matched_text(t)
        ).pack(side=tk.LEFT)
    
    def copy_matched_text(self, text):
        """Copy matched text to clipboard"""
        if text:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            messagebox.showinfo("📋 Copied", "Matched text copied to clipboard!")
        else:
            messagebox.showwarning("Warning", "No text to copy")
    
    def show_processing_window(self):
        """Show PDF processing progress window"""
        if self.processing_window is None or not self.processing_window.winfo_exists():
            self.processing_window = tk.Toplevel(self.root)
            self.processing_window.title("📖 Processing PDF...")
            self.processing_window.geometry("500x150")
            self.processing_window.resizable(False, False)
            self.processing_window.transient(self.root)
            self.processing_window.grab_set()
            
            # Progress elements
            ttk.Label(self.processing_window, text="🛠️ Processing PDF pages...", font=("Arial", 12)).pack(pady=(20, 10))
            
            self.progress_var = tk.DoubleVar()
            self.progress_bar = ttk.Progressbar(
                self.processing_window, 
                variable=self.progress_var, 
                maximum=100,
                length=400
            )
            self.progress_bar.pack(pady=(0, 10))
            
            self.progress_label = ttk.Label(self.processing_window, text="Page 0/0 | ETA: 0s | Elapsed: 0s")
            self.progress_label.pack()
            
            # Cancel button
            ttk.Button(self.processing_window, text="⏹️ Cancel", state="disabled").pack(pady=(10, 0))
    
    def update_progress(self, progress_info):
        """Update progress information"""
        if self.processing_window and self.processing_window.winfo_exists():
            self.progress_var.set(progress_info['percent'])
            self.progress_label.config(
                text=f"Page {progress_info['current']}/{progress_info['total']} | "
                     f"ETA: {progress_info['eta']} | "
                     f"Elapsed: {progress_info['elapsed']}"
            )
            self.processing_window.update()
    
    def hide_processing_window(self):
        """Hide processing window"""
        if self.processing_window and self.processing_window.winfo_exists():
            self.processing_window.destroy()
            self.processing_window = None
    
    def pdf_processed_successfully(self, pdf_path, page_count, processing_time):
        """Update UI after successful PDF processing"""
        self.hide_processing_window()
        
        filename = pdf_path.split("/")[-1].split("\\")[-1]
        self.file_label.config(text=filename)
        self.info_label.config(text=f"{page_count} pages | Processing time: {self.format_time(processing_time)}")
        self.view_extracted_btn.config(state="normal")
        self.status_bar.config(text=f"✅ PDF processed successfully: {filename}")
    
    def format_time(self, seconds):
        """Format seconds to human readable time"""
        mins = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{mins}m {secs}s" if mins > 0 else f"{secs}s"
    
    def show_extracted_text(self):
        """Show all extracted text from PDF"""
        if not self.app.pages_text:
            return
            
        if self.extracted_text_window is None or not self.extracted_text_window.winfo_exists():
            self.extracted_text_window = tk.Toplevel(self.root)
            self.extracted_text_window.title("📚 Extracted Text from PDF")
            self.extracted_text_window.geometry("800x600")
            self.extracted_text_window.minsize(600, 400)
            
            # Create extracted text view UI
            self.create_extracted_text_ui()
        else:
            # Update existing window
            self.update_extracted_text_view()
    
    def create_extracted_text_ui(self):
        """Create extracted text view interface"""
        # Main frame
        main_frame = ttk.Frame(self.extracted_text_window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(0, weight=1)
        
        # Header
        header_frame = ttk.Frame(main_frame)
        header_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        header_frame.columnconfigure(0, weight=1)
        
        ttk.Label(header_frame, text="📚 Extracted Text from PDF", font=("Arial", 14, "bold")).grid(row=0, column=0, sticky=tk.W)
        ttk.Button(header_frame, text="📎 Copy All Text", command=self.copy_all_text).grid(row=0, column=1, sticky=tk.E)
        
        # Text area with scrollbar
        text_frame = ttk.Frame(main_frame)
        text_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        text_frame.columnconfigure(0, weight=1)
        text_frame.rowconfigure(0, weight=1)
        
        self.extracted_text_area = scrolledtext.ScrolledText(
            text_frame, 
            wrap=tk.WORD, 
            font=("Arial", 11)
        )
        self.extracted_text_area.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Populate with extracted text
        self.update_extracted_text_view()
        
        # Close button
        ttk.Button(main_frame, text="❌ Close", command=self.extracted_text_window.destroy).grid(row=2, column=0, sticky=tk.E)
    
    def update_extracted_text_view(self):
        """Update extracted text view with current data"""
        if not hasattr(self, 'extracted_text_area') or not self.extracted_text_window.winfo_exists():
            return
            
        # Clear current content
        self.extracted_text_area.delete(1.0, tk.END)
        
        # Add all page texts with page separators
        for page_num in sorted(self.app.pages_text.keys()):
            page_content = self.app.pages_text[page_num]
            self.extracted_text_area.insert(
                tk.END, 
                f"{'='*60}\n"
                f"📄 Page {page_num}\n"
                f"{'='*60}\n"
                f"{page_content}\n\n"
            )
    
    def copy_all_text(self):
        """Copy all extracted text to clipboard"""
        if not self.app.pages_text:
            return
            
        # Build complete text
        full_text = ""
        for page_num in sorted(self.app.pages_text.keys()):
            page_content = self.app.pages_text[page_num]
            full_text += f"{'='*60}\n"
            full_text += f"📄 Page {page_num}\n"
            full_text += f"{'='*60}\n"
            full_text += f"{page_content}\n\n"
        
        self.extracted_text_window.clipboard_clear()
        self.extracted_text_window.clipboard_append(full_text)
        messagebox.showinfo("📋 Copied", "All extracted text copied to clipboard!", parent=self.extracted_text_window)
    
    def show_page_content(self, page_num, content, total_pages, matched_text=""):
        """Show content of a specific page with highlighting"""
        if self.page_window is None or not self.page_window.winfo_exists():
            self.page_window = tk.Toplevel(self.root)
            self.page_window.title(f"📄 Page {page_num} Content")
            self.page_window.geometry("700x600")
            self.page_window.minsize(600, 500)
            
            # Create page view UI
            self.create_page_view_ui(page_num, content, total_pages, matched_text)
        else:
            # Update existing window
            self.update_page_view(page_num, content, total_pages, matched_text)
    
    def create_page_view_ui(self, page_num, content, total_pages, matched_text=""):
        """Create page view interface with highlighting"""
        # Main frame
        main_frame = ttk.Frame(self.page_window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Page header
        header_frame = ttk.Frame(main_frame)
        header_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        header_frame.columnconfigure(1, weight=1)
        
        ttk.Label(header_frame, text=f"📄 Page {page_num}", font=("Arial", 14, "bold")).grid(row=0, column=0)
        self.page_counter_label = ttk.Label(header_frame, text=f"{page_num}/{total_pages}")
        self.page_counter_label.grid(row=0, column=1, sticky=tk.E)
        
        # Navigation buttons
        nav_frame = ttk.Frame(header_frame)
        nav_frame.grid(row=1, column=0, columnspan=2, sticky=tk.E, pady=(10, 0))
        
        ttk.Button(nav_frame, text="⬅️ Previous", state="disabled" if page_num == 1 else "normal",
                  command=lambda: self.navigate_page(page_num-1)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(nav_frame, text="Next ➡️", state="disabled" if page_num == total_pages else "normal",
                  command=lambda: self.navigate_page(page_num+1)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(nav_frame, text="🏠 Back to Search", command=self.page_window.destroy).pack(side=tk.LEFT, padx=(10, 0))
        
        # Content area
        content_frame = ttk.Frame(main_frame)
        content_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        content_frame.columnconfigure(0, weight=1)
        content_frame.rowconfigure(0, weight=1)
        
        # Create text widget with highlighting support
        self.page_content_text = tk.Text(content_frame, wrap=tk.WORD, font=("Arial", 11))
        scrollbar = ttk.Scrollbar(content_frame, orient="vertical", command=self.page_content_text.yview)
        self.page_content_text.configure(yscrollcommand=scrollbar.set)
        
        self.page_content_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # Insert content and apply highlighting
        self.page_content_text.insert(tk.END, content)
        if matched_text:
            self.highlight_text(content, matched_text)
        
        self.page_content_text.config(state=tk.DISABLED)
        
        # Action buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=2, column=0, sticky=(tk.W, tk.E))
        
        ttk.Button(button_frame, text="📎 Copy Page Text", 
                  command=lambda: self.copy_page_text(content)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="💾 Save Page", state="disabled").pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="🖨️ Print", state="disabled").pack(side=tk.LEFT)
    
    def update_page_view(self, page_num, content, total_pages, matched_text=""):
        """Update existing page view with highlighting"""
        self.page_counter_label.config(text=f"{page_num}/{total_pages}")
        self.page_content_text.config(state=tk.NORMAL)
        self.page_content_text.delete(1.0, tk.END)
        self.page_content_text.insert(tk.END, content)
        
        # Apply highlighting if there's matched text
        if matched_text:
            self.highlight_text(content, matched_text)
        
        self.page_content_text.config(state=tk.DISABLED)
    
    def highlight_text(self, page_content, search_text):
        """Highlight occurrences of search text in yellow (works with Bangla)"""
        if not search_text or not page_content:
            return
            
        # Clean the search text
        search_text = search_text.strip()
        if not search_text:
            return
            
        # Configure tag for highlighting
        self.page_content_text.tag_configure("highlight", background="yellow")
        
        # Find all occurrences of the search text in the page content
        start_pos = 0
        search_len = len(search_text)
        
        # Search for exact matches first
        while True:
            # Find the position of the search text in the page content
            pos = page_content.find(search_text, start_pos)
            if pos == -1:  # Not found
                break
                
            # Convert position to Text widget format (line.char)
            # Count lines and characters up to position
            text_up_to_pos = page_content[:pos]
            lines = text_up_to_pos.count('\n')
            if lines == 0:
                char_pos = pos
            else:
                last_newline = text_up_to_pos.rfind('\n')
                char_pos = pos - last_newline - 1
            
            # Create Text widget position strings
            start_widget_pos = f"{lines + 1}.{char_pos}"
            end_widget_pos = f"{lines + 1}.{char_pos + search_len}"
            
            # Apply highlighting
            self.page_content_text.tag_add("highlight", start_widget_pos, end_widget_pos)
            
            # Move to next position
            start_pos = pos + 1
            
            # Safety check to prevent infinite loop
            if start_pos >= len(page_content):
                break
    
    def navigate_page(self, page_num):
        """Navigate to different page"""
        if page_num in self.app.pages_text:
            content = self.app.pages_text[page_num]
            total_pages = len(self.app.pages_text)
            # Pass the last search text for highlighting
            self.update_page_view(page_num, content, total_pages, self.last_search_text)
    
    def copy_page_text(self, content):
        """Copy page content to clipboard"""
        self.page_window.clipboard_clear()
        self.page_window.clipboard_append(content)
        messagebox.showinfo("📋 Copied", "Page content copied to clipboard!", parent=self.page_window)