import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
from pdf_processor import PDFProcessor
from search_engine import SearchEngine
from ui_components import PDFSearchUI

class PDFSearchApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("📚 PDF Text Search Assistant (Bangla Support)")
        self.root.geometry("900x700")
        self.root.minsize(800, 600)
        
        # Initialize components
        self.pdf_processor = PDFProcessor()
        self.search_engine = None
        self.pages_text = {}
        
        # Create UI
        self.ui = PDFSearchUI(self.root, self)
        
    def select_pdf(self):
        """Handle PDF selection"""
        file_path = filedialog.askopenfilename(
            title="Select a PDF File",
            filetypes=[("PDF Files", "*.pdf")]
        )
        
        if file_path:
            self.process_pdf(file_path)
    
    def process_pdf(self, pdf_path):
        """Process selected PDF file"""
        try:
            # Show processing window
            self.ui.show_processing_window()
            
            # Process PDF
            self.pages_text, processing_time = self.pdf_processor.extract_text_from_pdf(
                pdf_path, 
                self.ui.update_progress
            )
            
            if self.pages_text:
                self.search_engine = SearchEngine(self.pages_text)
                self.ui.pdf_processed_successfully(pdf_path, len(self.pages_text), processing_time)
            else:
                self.ui.hide_processing_window()
                messagebox.showerror("Error", "Failed to extract text from PDF")
                
        except Exception as e:
            self.ui.hide_processing_window()
            messagebox.showerror("Error", f"Failed to process PDF: {str(e)}")
    
    def search_text(self, search_text):
        """Perform text search"""
        if not self.search_engine:
            messagebox.showwarning("Warning", "Please select and process a PDF first")
            return
            
        if not search_text.strip():
            messagebox.showwarning("Warning", "Please enter text to search")
            return
            
        results = self.search_engine.search(search_text)
        self.ui.display_search_results(results)
    
    def view_page(self, page_num, matched_text=""):
        """View specific page content with highlighting"""
        if page_num in self.pages_text:
            page_content = self.pages_text[page_num]
            self.ui.show_page_content(page_num, page_content, len(self.pages_text), matched_text)
    
    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = PDFSearchApp()
    app.run()