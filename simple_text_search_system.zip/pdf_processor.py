import time
from pdf2image import convert_from_path
import pytesseract
from PIL import Image
import sys
import os

class PDFProcessor:
    def __init__(self):
        # Configure paths if needed (Windows)
        # pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
        # self.poppler_path = r'C:\path\to\poppler\bin'  # Uncomment for Windows
        self.poppler_path = None  # Set to None for Linux/Mac
        
    def format_time(self, seconds):
        """Format time in minutes and seconds"""
        mins = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{mins}m {secs}s" if mins > 0 else f"{secs}s"
    
    def update_progress_callback(self, current, total, start_time, progress_callback=None):
        """Update progress during PDF processing"""
        elapsed = time.perf_counter() - start_time
        percent = (current / total) * 100
        bar_length = 30
        filled_length = int(bar_length * current // total)
        bar = '█' * filled_length + '-' * (bar_length - filled_length)
        
        time_per_step = elapsed / current if current else 0
        eta = time_per_step * (total - current)
        
        progress_info = {
            'percent': percent,
            'current': current,
            'total': total,
            'eta': self.format_time(eta),
            'elapsed': self.format_time(elapsed)
        }
        
        if progress_callback:
            progress_callback(progress_info)
    
    def extract_text_from_pdf(self, pdf_path, progress_callback=None):
        """Extract text from PDF using OCR with enhanced Bangla support"""
        try:
            start_time = time.perf_counter()
            
            # Convert PDF to images
            if self.poppler_path:
                images = convert_from_path(pdf_path, poppler_path=self.poppler_path)
            else:
                images = convert_from_path(pdf_path)
                
            total_pages = len(images)
            pages_text = {}
            
            # Process each page with enhanced Bangla OCR settings
            for i, img in enumerate(images):
                # Enhanced OCR configuration for Bangla
                # Using both 'ben' and 'eng' for mixed content
                # Adding OCR options for better accuracy
                custom_config = r'--oem 1 --psm 6 -c preserve_interword_spaces=1'
                text = pytesseract.image_to_string(
                    img, 
                    lang='ben+eng', 
                    config=custom_config
                )
                pages_text[i + 1] = text.strip()
                
                # Update progress
                self.update_progress_callback(i + 1, total_pages, start_time, progress_callback)
            
            total_time = time.perf_counter() - start_time
            return pages_text, total_time
            
        except Exception as e:
            raise Exception(f"PDF processing error: {str(e)}")