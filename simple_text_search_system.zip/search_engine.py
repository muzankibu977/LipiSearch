import re
from difflib import SequenceMatcher

class SearchEngine:
    def __init__(self, pages_text):
        self.pages_text = pages_text
    
    def normalize_text(self, text):
        """Normalize text for better matching while preserving Bangla characters"""
        if not text:
            return ""
        # Remove extra whitespace but preserve Bangla characters
        text = re.sub(r'\s+', ' ', text)
        return text.strip()
    
    def calculate_similarity(self, text1, text2):
        """Calculate similarity ratio between two texts (works with Bangla)"""
        return SequenceMatcher(None, text1, text2).ratio()
    
    def find_text_in_page(self, page_text, search_text, min_similarity=0.6):
        """Find search text in page content with better Bangla support"""
        if not page_text or not search_text:
            return None
        
        # Normalize both texts
        normalized_page = self.normalize_text(page_text)
        normalized_search = self.normalize_text(search_text)
        
        # Direct substring search (most reliable for exact matches)
        if normalized_search in normalized_page:
            # Find position for preview
            pos = normalized_page.find(normalized_search)
            start_pos = max(0, pos - 100)
            end_pos = min(len(page_text), pos + len(search_text) + 100)
            preview = page_text[start_pos:end_pos].strip()
            
            return {
                'match_type': 'exact',
                'confidence': 1.0,
                'preview': preview,
                'position': pos,
                'matched_text': normalized_search  # Added for highlighting
            }
        
        # For partial matches, try with cleaned text
        clean_page = re.sub(r'\s+', '', normalized_page)
        clean_search = re.sub(r'\s+', '', normalized_search)
        
        if clean_search in clean_page:
            pos = clean_page.find(clean_search)
            start_pos = max(0, pos - 100)
            end_pos = min(len(page_text), pos + len(search_text) + 100)
            preview = page_text[start_pos:end_pos].strip()
            
            return {
                'match_type': 'cleaned',
                'confidence': 0.9,
                'preview': preview,
                'position': pos,
                'matched_text': normalized_search  # Added for highlighting
            }
        
        # Fuzzy match for similar but not exact matches
        similarity = self.calculate_similarity(normalized_page, normalized_search)
        if similarity >= min_similarity:
            search_part = normalized_search[:min(20, len(normalized_search))]
            if search_part:
                pos = normalized_page.find(search_part)
                if pos == -1:
                    pos = 0
                start_pos = max(0, pos - 100)
                end_pos = min(len(page_text), pos + len(search_text) + 100)
                preview = page_text[start_pos:end_pos].strip()
                
                return {
                    'match_type': 'fuzzy',
                    'confidence': similarity,
                    'preview': preview,
                    'position': pos,
                    'matched_text': normalized_search  # Added for highlighting
                }
        
        return None
    
    def search(self, search_text):
        """Search for text across all pages with improved Bangla support"""
        if not search_text.strip():
            return []
        
        results = []
        
        for page_num, page_content in self.pages_text.items():
            match_info = self.find_text_in_page(page_content, search_text)
            
            if match_info:
                results.append({
                    'page_num': page_num,
                    'confidence': match_info['confidence'],
                    'preview': match_info['preview'],
                    'match_type': match_info['match_type'],
                    'matched_text': match_info['matched_text']  # Added for highlighting
                })
        
        # Sort by confidence (highest first)
        results.sort(key=lambda x: x['confidence'], reverse=True)
        return results